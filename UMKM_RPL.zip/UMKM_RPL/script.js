// ================= MODAL =================

// buka modal detail produk
function openModalDetail(imgElement) {
    const modal = document.getElementById("modal");
    const modalImg = document.getElementById("modal-img");
    const modalTitle = document.getElementById("modal-title");
    const modalPrice = document.getElementById("modal-price");
    const modalDesc = document.getElementById("modal-desc");

    const card = imgElement.closest(".product-card");

    const nama = card.dataset.nama;
    const harga = parseInt(card.dataset.harga);
    const desc = card.dataset.deskripsi;

    modalImg.src = imgElement.src;
    modalTitle.innerText = nama;
    modalPrice.innerText = "Rp " + harga.toLocaleString("id-ID");
    modalDesc.innerText = desc;

    modal.style.display = "flex";
}

// tutup modal
function closeModal() {
    document.getElementById("modal").style.display = "none";
}

// ESC untuk close modal
document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") {
        closeModal();
    }
});


// ================= SCROLL NAVBAR =================
window.addEventListener("scroll", function () {
    const navbar = document.querySelector(".navbar");

    if (window.scrollY > 50) {
        navbar.style.background = "#6f4e37";
    } else {
        navbar.style.background = "rgba(111, 78, 55, 0.9)";
    }
});


// ================= QTY CONTROL =================

// tambah jumlah
function tambah(btn) {
    const qtyEl = btn.parentElement.querySelector(".qty");
    let qty = parseInt(qtyEl.innerText);

    qtyEl.innerText = qty + 1;
}

// kurang jumlah
function kurang(btn) {
    const qtyEl = btn.parentElement.querySelector(".qty");
    let qty = parseInt(qtyEl.innerText);

    if (qty > 0) {
        qtyEl.innerText = qty - 1;
    }
}


// ================= WHATSAPP =================

function kirimWhatsApp() {
    const cards = document.querySelectorAll(".product-card");

    let pesan = "Halo, saya ingin memesan:%0A";
    let total = 0;
    let adaPesanan = false;

    cards.forEach(card => {
        const nama = card.dataset.nama;
        const harga = parseInt(card.dataset.harga);
        const qtyEl = card.querySelector(".qty");

        // handle kalau ada produk tanpa qty (biar tidak error)
        if (!qtyEl) return;

        const qty = parseInt(qtyEl.innerText);

        if (qty > 0) {
            adaPesanan = true;

            let subtotal = harga * qty;
            total += subtotal;

            pesan += `- ${nama} (${qty}) = Rp ${subtotal}%0A`;
        }
    });

    if (!adaPesanan) {
        alert("Pilih minimal 1 produk!");
        return;
    }

    pesan += `%0ATotal: Rp ${total}`;

    const url = `https://wa.me/6285730822599?text=${pesan}`;
    window.open(url, "_blank");
}


// ================= FILTER KATEGORI =================

function filterProduk(kategori) {
    const grid = document.querySelector(".product-grid");
    const cards = document.querySelectorAll(".product-card");
    const btnKembali = document.querySelector(".btn-kembali");

    // tampilkan produk
    grid.style.display = "grid";

    // tampilkan tombol kembali
    if (btnKembali) {
        btnKembali.style.display = "block";
    }

    cards.forEach(card => {
        const kategoriProduk = card.dataset.kategori;

        if (kategoriProduk === kategori) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}


// ================= RESET =================

function resetProduk() {
    const grid = document.querySelector(".product-grid");
    const btnKembali = document.querySelector(".btn-kembali");

    grid.style.display = "none";

    if (btnKembali) {
        btnKembali.style.display = "none";
    }
}